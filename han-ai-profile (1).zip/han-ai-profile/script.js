/* =========================================================
   한희경 AI 강사 공식 홈페이지 — script.js
   SNS 주소는 이 파일 상단 SNS_LINKS 배열 한 곳에서만 관리합니다.
   ========================================================= */

/* -------- 1) SNS 채널 정보 (여기만 수정하면 전체 반영됩니다) -------- */
const SNS_LINKS = [
  {
    name: "유튜브",
    desc: "한희경TV · AI 강의와 영상 콘텐츠",
    url: "https://www.youtube.com/@한희경TV",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3V9z" fill="currentColor" stroke="none"/></svg>`
  },
  {
    name: "페이스북",
    desc: "강의 소식과 다양한 활동 이야기",
    url: "https://facebook.com/queenofqn",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M14 8h-1.5A2.5 2.5 0 0 0 10 10.5V12H8v2h2v6h2.5v-6H15l.5-2h-3v-1.2c0-.44.36-.8.8-.8H15V8z" fill="currentColor" stroke="none"/></svg>`
  },
  {
    name: "네이버 블로그",
    desc: "AI 활용법, 강의 후기, 콘텐츠 제작 정보",
    url: "https://blog.naver.com/bighappygirl",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v16H4z"/><path d="M8 8v8M8 8l4 5.5V8h4v8" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  {
    name: "인스타그램",
    desc: "강의 현장, 숏폼, 이미지 콘텐츠",
    url: "https://instagram.com/queenofqn7",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none"/></svg>`
  },
  {
    name: "틱톡",
    desc: "짧고 재미있는 AI 콘텐츠 숏폼",
    url: "https://www.tiktok.com/@queenofqn7",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 3v10.5a3.5 3.5 0 1 1-3-3.46" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 3c.4 2.4 2.2 4.2 4.6 4.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  {
    name: "패들렛",
    desc: "AI 강의자료와 수업 학습 보드",
    url: "https://padlet.com/queenofqn7/han_ai_class",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="10" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/></svg>`
  }
];

/* -------- 2) 활용 AI 도구 목록 -------- */
const AI_TOOLS = [
  "ChatGPT", "Gemini", "Claude", "Codex", "Hermes", "Microsoft Copilot",
  "Canva", "Vrew", "CapCut", "Runway", "Sora", "Kling",
  "Suno", "Google AI Studio", "GitHub", "Netlify"
];

/* -------- 3) SNS 버튼 렌더링 -------- */
function renderSnsButtons() {
  const grid = document.getElementById("snsGrid");
  if (!grid) return;

  grid.innerHTML = SNS_LINKS.map(item => `
    <a class="sns-btn" href="${item.url}" target="_blank" rel="noopener noreferrer" aria-label="${item.name} 바로가기">
      <span class="sns-icon" aria-hidden="true">${item.icon}</span>
      <span class="sns-text">
        <strong>${item.name}</strong>
        <span>${item.desc}</span>
      </span>
      <span class="sns-ext" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 17L17 7M9 7h8v8"/></svg>
      </span>
    </a>
  `).join("");
}

/* -------- 4) AI 도구 마키(흐르는 배지) 렌더링 -------- */
function renderToolMarquee() {
  const track = document.getElementById("toolTrack");
  if (!track) return;

  // 무한 스크롤처럼 보이도록 목록을 두 번 반복
  const doubled = [...AI_TOOLS, ...AI_TOOLS];
  track.innerHTML = doubled
    .map(tool => `<span class="tool-badge" role="listitem">${tool}</span>`)
    .join("");
}

/* -------- 5) 프로필 사진이 없을 때 이니셜로 대체 -------- */
function handleProfileImageFallback() {
  const img = document.getElementById("profileImg");
  const panel = document.querySelector(".photo-panel");
  if (!img || !panel) return;

  img.addEventListener("error", () => {
    panel.classList.add("no-image");
  });
}

/* -------- 6) 현재 페이지 링크 복사 -------- */
function setupCopyLink() {
  const btn = document.getElementById("copyLinkBtn");
  const label = document.getElementById("copyBtnLabel");
  if (!btn) return;

  btn.addEventListener("click", async () => {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
    } catch (e) {
      // 클립보드 API를 사용할 수 없는 경우를 위한 대체 방법
      const temp = document.createElement("textarea");
      temp.value = url;
      document.body.appendChild(temp);
      temp.select();
      document.execCommand("copy");
      document.body.removeChild(temp);
    }
    btn.classList.add("copied");
    label.textContent = "링크가 복사되었습니다";
    setTimeout(() => {
      btn.classList.remove("copied");
      label.textContent = "현재 페이지 링크 복사";
    }, 2000);
  });
}

/* -------- 초기화 -------- */
document.addEventListener("DOMContentLoaded", () => {
  renderSnsButtons();
  renderToolMarquee();
  handleProfileImageFallback();
  setupCopyLink();
});
